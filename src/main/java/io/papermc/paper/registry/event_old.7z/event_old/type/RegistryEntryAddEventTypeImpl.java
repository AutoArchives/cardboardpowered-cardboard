/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.plugin.bootstrap.BootstrapContext
 *  io.papermc.paper.plugin.lifecycle.event.handler.LifecycleEventHandler
 *  io.papermc.paper.registry.RegistryBuilder
 *  io.papermc.paper.registry.RegistryKey
 *  io.papermc.paper.registry.event.RegistryEntryAddEvent
 *  io.papermc.paper.registry.event.type.RegistryEntryAddConfiguration
 *  io.papermc.paper.registry.event.type.RegistryEntryAddEventType
 */
package io.papermc.paper.registry.event.type;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.lifecycle.event.handler.LifecycleEventHandler;
import io.papermc.paper.plugin.lifecycle.event.types.AbstractLifecycleEventType;
import io.papermc.paper.plugin.lifecycle.event.types.PrioritizableLifecycleEventType;
import io.papermc.paper.registry.RegistryBuilder;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.event.RegistryEntryAddEvent;
import io.papermc.paper.registry.event.type.RegistryEntryAddConfiguration;
import io.papermc.paper.registry.event.type.RegistryEntryAddEventType;
import io.papermc.paper.registry.event.type.RegistryEntryAddHandlerConfiguration;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class RegistryEntryAddEventTypeImpl<T, B extends RegistryBuilder<T>>
extends PrioritizableLifecycleEventType<BootstrapContext, RegistryEntryAddEvent<T, B>, RegistryEntryAddConfiguration<T>>
implements RegistryEntryAddEventType<T, B> {
    public RegistryEntryAddEventTypeImpl(RegistryKey<T> registryKey, String eventName) {
        super(String.valueOf(registryKey) + " / " + eventName, BootstrapContext.class);
    }

    @Override
    public boolean blocksReloading(BootstrapContext eventOwner) {
        return false;
    }

    public RegistryEntryAddConfiguration<T> newHandler(LifecycleEventHandler<? super RegistryEntryAddEvent<T, B>> handler) {
        return new RegistryEntryAddHandlerConfiguration(handler, this);
    }

    @Override
    public void forEachHandler(RegistryEntryAddEvent<T, B> event, Consumer<AbstractLifecycleEventType.RegisteredHandler<BootstrapContext, RegistryEntryAddEvent<T, B>>> consumer, Predicate<AbstractLifecycleEventType.RegisteredHandler<BootstrapContext, RegistryEntryAddEvent<T, B>>> predicate) {
        super.forEachHandler(event, consumer, predicate.and(handler -> this.matchesTarget(event, (AbstractLifecycleEventType.RegisteredHandler<BootstrapContext, RegistryEntryAddEvent<T, B>>)handler)));
    }

    private boolean matchesTarget(RegistryEntryAddEvent<T, B> event, AbstractLifecycleEventType.RegisteredHandler<BootstrapContext, RegistryEntryAddEvent<T, B>> handler) {
        RegistryEntryAddHandlerConfiguration config = (RegistryEntryAddHandlerConfiguration)handler.config();
        return config.filter() == null || config.filter().test(event.key());
    }
}

