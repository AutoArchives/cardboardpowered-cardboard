/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.plugin.bootstrap.BootstrapContext
 *  io.papermc.paper.plugin.lifecycle.event.types.LifecycleEventType$Prioritizable
 *  io.papermc.paper.registry.RegistryBuilder
 *  io.papermc.paper.registry.event.RegistryEventProvider
 *  io.papermc.paper.registry.event.RegistryEventTypeProvider
 *  io.papermc.paper.registry.event.RegistryFreezeEvent
 *  io.papermc.paper.registry.event.type.RegistryEntryAddEventType
 */
package io.papermc.paper.registry.event;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEventType;
import io.papermc.paper.registry.PaperRegistryListenerManager;
import io.papermc.paper.registry.RegistryBuilder;
import io.papermc.paper.registry.event.RegistryEventProvider;
import io.papermc.paper.registry.event.RegistryEventTypeProvider;
import io.papermc.paper.registry.event.RegistryFreezeEvent;
import io.papermc.paper.registry.event.type.RegistryEntryAddEventType;

public class RegistryEventTypeProviderImpl
implements RegistryEventTypeProvider {
    public static RegistryEventTypeProviderImpl instance() {
        return (RegistryEventTypeProviderImpl)RegistryEventTypeProvider.provider();
    }

    public <T, B extends RegistryBuilder<T>> RegistryEntryAddEventType<T, B> registryEntryAdd(RegistryEventProvider<T, B> type) {
        return PaperRegistryListenerManager.INSTANCE.getRegistryValueAddEventType(type);
    }

    public <T, B extends RegistryBuilder<T>> LifecycleEventType.Prioritizable<BootstrapContext, RegistryFreezeEvent<T, B>> registryFreeze(RegistryEventProvider<T, B> type) {
        return PaperRegistryListenerManager.INSTANCE.getRegistryFreezeEventType(type);
    }
}

