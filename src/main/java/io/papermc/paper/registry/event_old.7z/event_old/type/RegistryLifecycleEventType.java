/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.plugin.bootstrap.BootstrapContext
 *  io.papermc.paper.registry.RegistryKey
 *  io.papermc.paper.registry.event.RegistryEvent
 */
package io.papermc.paper.registry.event.type;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.lifecycle.event.types.PrioritizableLifecycleEventType;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.event.RegistryEvent;

public final class RegistryLifecycleEventType<T, E extends RegistryEvent<T>>
extends PrioritizableLifecycleEventType.Simple<BootstrapContext, E> {
    public RegistryLifecycleEventType(RegistryKey<T> registryKey, String eventName) {
        super(String.valueOf(registryKey) + " / " + eventName, BootstrapContext.class);
    }

    @Override
    public boolean blocksReloading(BootstrapContext eventOwner) {
        return false;
    }
}

