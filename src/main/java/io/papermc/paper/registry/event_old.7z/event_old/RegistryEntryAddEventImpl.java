/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.registry.RegistryBuilder
 *  io.papermc.paper.registry.RegistryKey
 *  io.papermc.paper.registry.TypedKey
 *  io.papermc.paper.registry.event.RegistryEntryAddEvent
 *  io.papermc.paper.registry.tag.Tag
 *  io.papermc.paper.registry.tag.TagKey
 *  org.bukkit.Keyed
 *  org.checkerframework.checker.nullness.qual.NonNull
 */
package io.papermc.paper.registry.event;

import io.papermc.paper.plugin.lifecycle.event.PaperLifecycleEvent;
import io.papermc.paper.registry.PaperRegistries;
import io.papermc.paper.registry.RegistryBuilder;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.TypedKey;
import io.papermc.paper.registry.data.util.Conversions;
import io.papermc.paper.registry.event.RegistryEntryAddEvent;
import io.papermc.paper.registry.set.NamedRegistryKeySetImpl;
import io.papermc.paper.registry.tag.Tag;
import io.papermc.paper.registry.tag.TagKey;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.entry.RegistryEntryList;
import org.bukkit.Keyed;
import org.checkerframework.checker.nullness.qual.NonNull;

public record RegistryEntryAddEventImpl<T, B extends RegistryBuilder<T>>(TypedKey<T> key, B builder, RegistryKey<T> registryKey, Conversions conversions) implements RegistryEntryAddEvent<T, B>,
PaperLifecycleEvent
{
    public <V extends Keyed> @NonNull Tag<V> getOrCreateTag(TagKey<V> tagKey) {
        RegistryOps.RegistryInfo registryInfo = this.conversions.lookup().getRegistryInfo(PaperRegistries.registryToNms(tagKey.registryKey())).orElseThrow();
        RegistryEntryList.Named tagSet = registryInfo.entryLookup().getOrThrow(PaperRegistries.toNms(tagKey));
        return new NamedRegistryKeySetImpl(tagKey, tagSet);
    }
}

