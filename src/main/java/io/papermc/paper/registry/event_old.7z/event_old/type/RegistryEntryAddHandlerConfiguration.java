/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.papermc.paper.plugin.bootstrap.BootstrapContext
 *  io.papermc.paper.plugin.lifecycle.event.handler.LifecycleEventHandler
 *  io.papermc.paper.registry.RegistryBuilder
 *  io.papermc.paper.registry.TypedKey
 *  io.papermc.paper.registry.event.RegistryEntryAddEvent
 *  io.papermc.paper.registry.event.type.RegistryEntryAddConfiguration
 *  org.checkerframework.checker.nullness.qual.Nullable
 *  org.jetbrains.annotations.Contract
 */
package io.papermc.paper.registry.event.type;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.lifecycle.event.handler.LifecycleEventHandler;
import io.papermc.paper.plugin.lifecycle.event.handler.configuration.PrioritizedLifecycleEventHandlerConfigurationImpl;
import io.papermc.paper.plugin.lifecycle.event.types.AbstractLifecycleEventType;
import io.papermc.paper.registry.RegistryBuilder;
import io.papermc.paper.registry.TypedKey;
import io.papermc.paper.registry.event.RegistryEntryAddEvent;
import io.papermc.paper.registry.event.type.RegistryEntryAddConfiguration;
import java.util.function.Predicate;
import org.checkerframework.checker.nullness.qual.Nullable;
import org.jetbrains.annotations.Contract;

public class RegistryEntryAddHandlerConfiguration<T, B extends RegistryBuilder<T>>
extends PrioritizedLifecycleEventHandlerConfigurationImpl<BootstrapContext, RegistryEntryAddEvent<T, B>>
implements RegistryEntryAddConfiguration<T> {
    private @Nullable Predicate<TypedKey<T>> filter;

    public RegistryEntryAddHandlerConfiguration(LifecycleEventHandler<? super RegistryEntryAddEvent<T, B>> handler, AbstractLifecycleEventType<BootstrapContext, RegistryEntryAddEvent<T, B>, ?> eventType) {
        super(handler, eventType);
    }

    @Contract(pure=true)
    public @Nullable Predicate<TypedKey<T>> filter() {
        return this.filter;
    }

    public RegistryEntryAddConfiguration<T> filter(Predicate<TypedKey<T>> filter) {
        this.filter = filter;
        return this;
    }

    @Override
    public RegistryEntryAddConfiguration<T> priority(int priority) {
        return (RegistryEntryAddConfiguration)super.priority(priority);
    }

    @Override
    public RegistryEntryAddConfiguration<T> monitor() {
        return (RegistryEntryAddConfiguration)super.monitor();
    }
}

